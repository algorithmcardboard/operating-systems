#Scheduler - Lab2

**Author** Anirudhan Jegannathan Rajagopalan

**N-Number** N18824115

**Email** ajr619@nyu.edu

##How to compile?
    make clean
    make

##How to run?
    Run the 'mmu' object created src folder.
